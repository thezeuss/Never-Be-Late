const express = require("express");
const router = require("./web/routes.js");

const app = express();
const PORT = 8000;

app.use(router);
 
app.listen(PORT, () => {
    console.log(`server is running on ${PORT} Port.`)
})