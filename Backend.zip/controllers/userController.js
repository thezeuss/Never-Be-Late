const { OAuth2Client } = require("google-auth-library");
const client = new OAuth2Client(process.env.CLIENT_ID);
const user = require("../schema/userSchema.js")

const loginWithGoogle = async (token, res) => {
    const ticket = await client.verifyIdToken({
        idToken: token,
        audience: process.env.CLIENT_ID,
    });
    const { name, email, picture, given_name } = ticket.getPayload();

    let userExists = await user.aggregate([
        {
            $match: {
                email,
            },
        },
        {
            $lookup: {
                from: "profiles",
                localField: "followers",
                foreignField: "_id",
                as: "followers",
            },
        },
        {
            $lookup: {
                from: "profiles",
                localField: "following",
                foreignField: "_id",
                as: "following",
            },
        },
    ]);

    console.log(userExists[0]);

    // If yes then return profile
    if (userExists[0]) {
        let data = {
            id: userExists[0]._id,
            username: userExists[0].username,
        };
        let authToken = jwt.sign(data, "Meshv#1341");
        return res.json({ result: true, authToken, profile: userExists[0] });
    }

    // If not then create profile for'em in our db
    const user = await user.create({
        username: given_name,
        email,
        name,
        Profile_pic: picture,
    });

    let profile = await user.aggregate([
        {
            $match: {
                username: given_name,
            },
        },
        {
            $lookup: {
                from: "profiles",
                localField: "followers",
                foreignField: "_id",
                as: "followers",
            },
        },
        {
            $lookup: {
                from: "profiles",
                localField: "following",
                foreignField: "_id",
                as: "following",
            },
        },
    ]);

    let data = {
        id: profile[0]._id,
        username: user.username,
    };
    let authToken = jwt.sign(data, "Meshv#1341");

    return res.json({ result: true, authToken, profile: profile[0] });
};

module.exports = loginWithGoogle;