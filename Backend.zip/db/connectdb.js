const mongoose = require("mongoose")

const connectDb = async () => {
    try {
        const dbOptions = {
            dbName: "task"
        }
        await mongoose.connect("mongodb://localhost:27017", dbOptions);
    } catch (error) {
        console.log("Internal server error");
    }
}

module.exports = connectDb;