const mongoose = require("mongoose")

const userSchema = new mongoose.Schema({
    email: {
        type: String,
        required: [true, 'Please provide a name!'],
        maxlength: [40, 'Name should be under 40 characters.']
    },

    password: {
        type: String,
        required: true,
        select: false
    }
})

module.exports = mongoose.model("User", userSchema)