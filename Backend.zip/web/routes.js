const express = require("express");
const controller = require("../controllers/userController.js")

const router = express.Router();

router.get("/", controller)

module.exports = router